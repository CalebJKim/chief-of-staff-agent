---
title: Executive Second Brain
created: 2026-09-09
updated: 2026-09-22
type: summary
tags: [priority, operations, strategy]
sources: []
status: active
confidence: high
---

# Executive Second Brain

## Current priorities
1. Settle the [[neoagent-v2-launch|NeoAgent V2 launch]] storyline and final [[gtc-demo-slate|GTC demo slate]] at the [[neoagent-v2-executive-review|Executive Review]].
2. Review, update, and finalize the [[agent-security-prd|Agent Security PRD]], deciding the open fallback policies and audit requirements.
3. Carry [[performance-results|the approved performance results]] into the executive deck and [[marketing-claims-rollout|marketing materials]].

## Decisions requiring attention
- Priya needs only the user's preferred [[marketing-shoot|shoot date]]; she handles booking and production arrangements.
- Assign the final retail experience owner in the GTC demo slate.
- Decide which outbound network access [[openshell|OpenShell]] permits by default.

These notes retain source dates and recorded status. Check current source-system information before acting; planning ideas here are not new approvals or completed work.

## Start here
- [[index|Wiki index]]
- [[decision-log|Decision log]]
- [[people-map|People map]]
- [[project-portfolio|Project portfolio]]
- [[weekly-executive-brief|Weekly executive brief]]

## Beyond the launch
[[q4-operating-plan|The Q4 operating plan]], [[finance-operating-plan|finance plan]], and [[pricing-and-packaging|pricing and packaging]] connect business outcomes with resources and commercial choices.

[[workforce-plan|Workforce planning]], [[leadership-succession|leadership succession]], and [[executive-recruiting|executive recruiting]] cover role coverage, development, continuity, and hiring.

The [[customer-portfolio-brief|customer portfolio brief]] compares account needs. [[enterprise-support-model|The enterprise support model]] and [[operational-resilience|operational resilience]] explain proposed support and recovery work. [[data-governance-program|Data governance]], [[developer-ecosystem-expansion|developer education]], and [[partner-certification|partner certification]] cover how information is handled and how people learn and support integrations.

## Detailed working briefs
[[meridian-strategic-account|Meridian's account plan]] describes a proposed internal policy-reference evaluation: operations users, an approved document collection, citations, and open acceptance questions.

[[northstar-customer-recovery|Northstar's recovery plan]] addresses a different problem, the missing handoff from implementation to support. It lays out a proposed recovery sequence and the customer confirmation still needed.

The Q4 plan compares onboarding, developer education, and documentation work. Follow the workforce plan for coverage options, developer education for the workshop-to-support sequence, and data governance for how documents are maintained and corrected. Operational resilience describes a proposed exercise for an unavailable document source.

People and meeting notes explain who can inform those discussions. Raw source records retain the historical evidence; the working briefs do not record new approvals, performance results, or completed customer work.
